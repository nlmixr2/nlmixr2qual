ui <- function () 
{
    ini({
        tka <- 0.464451132923658
        tcl <- c(-Inf, 1.01204689833242, 4.60517018598809)
        tv <- 3.45997310165565
        add.sd <- c(0, 0.693839405708945)
        eta.ka ~ 0.404625391044372
        eta.cl ~ 0.0687956048901995
        eta.v ~ 0.019222348721803
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        linCmt() ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "one.cmt", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

